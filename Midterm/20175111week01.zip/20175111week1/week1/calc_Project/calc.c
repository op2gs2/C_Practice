/*

*/


#include <stdio.h>

int main(int argc, char* agrv[]) {
	puts("hello c");



	return 0;
}